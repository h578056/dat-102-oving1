package no.hvl.dat102;

import org.junit.Before;

import no.hvl.dat102.adt.KoeADT;
import no.hvl.dat102.kjedetkoe.KjedetKoe;

public class KjedetKoeTest extends SirkulaerKoeTest{
	
	public KoeADT getkoe(){
		return new KjedetKoe();	
	}
}
