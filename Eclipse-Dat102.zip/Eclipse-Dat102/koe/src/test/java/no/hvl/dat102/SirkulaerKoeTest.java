package no.hvl.dat102;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import no.hvl.dat102.adt.KoeADT;
import no.hvl.dat102.klient.Kunde;
import no.hvl.dat102.sirkulaerkoe.SirkulaerKoe;

public class SirkulaerKoeTest {
	private final static int ANT_KUNDER = 100;		// Antall kunder i alt
	private KoeADT<Kunde> koe;
	private Kunde forste;

	public KoeADT getkoe(){
		return new SirkulaerKoe(ANT_KUNDER);
		
	}
	@Before
	public void fyllkoe() {
		koe=getkoe();
		for(int i=0; i<ANT_KUNDER; i++) {
			if(i==0) {
				forste= new Kunde(i);
				koe.innKoe(forste);
			}else {
			koe.innKoe(new Kunde(i));
			}
		}
	}
	
	@Test
	public void tom() {
		assertFalse(koe.erTom());
	}
	@Test
	public void antall() {
		assertEquals(ANT_KUNDER, koe.antall());
	}
	@Test
	public void utkoe() {
		koe.utKoe();
		assertEquals(ANT_KUNDER-1, koe.antall());
	}
	@Test
	public void forste() {
		assertEquals(forste, koe.foerste());
		assertEquals(forste, koe.utKoe());
	}
	@Test
	public void tomingKoe() {
		int count=0;
		
		while(koe.antall()>0) {
			koe.utKoe();
			count++;
		}
		assertEquals(count, ANT_KUNDER);
	}
	@Test
	public void utvidKoe() {
		Kunde kundetest= new Kunde(ANT_KUNDER+1);
		Kunde kundetest1= new Kunde(ANT_KUNDER+2);
		koe.innKoe(kundetest);
		koe.innKoe(kundetest1);
		Kunde siste=null;
		int count=0;
		while(count<ANT_KUNDER+2) {
			siste=koe.utKoe();
			count++;
		}
		assertEquals(kundetest1, siste);
	}
	}
