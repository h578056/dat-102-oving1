package no.hvl.dat102.sirkulaerkoe;

import no.hvl.dat102.adt.KoeADT;
import no.hvl.dat102.tabell.TabellKoe;

public class SirkulaerKoe<T> implements KoeADT<T> {
	private int ANT_TAB;
	private T[] koeTab;
	private int antall=0;
	private int forste=0;
	private int bak=0;
	
	public SirkulaerKoe(int ant) {
		ANT_TAB=ant;
		koeTab=(T[])(new Object[ANT_TAB]);
	}
	
	
	@Override
	public void innKoe(T element) {
		// TODO Auto-generated method stub
		if(antall<koeTab.length) {
			koeTab[bak]=element;
			antall++;
			bak++;
			if(antall==koeTab.length) {
				utvid();
			}
			if(bak==koeTab.length) {
				bak=0;
			}
		}
	}
	public void utvid() {
		T[] hjelptab=(T[])(new Object[(int) (ANT_TAB*1.2)]);
		for(int i=0; i<koeTab.length; i++) {
			hjelptab[i]=koeTab[i];
		}
		ANT_TAB=hjelptab.length;
		koeTab=hjelptab;
	}

	@Override
	public T utKoe() {
		// TODO Auto-generated method stub
		T utElement=null;
		if(antall!=0) {
			utElement=koeTab[forste];
			koeTab[forste]=null;
			antall--;
			forste++;
			if(forste== koeTab.length) {
				forste=0;
			}
		}
		return utElement;
	}

	@Override
	public T foerste() {
		// TODO Auto-generated method stub'
		T fElm=koeTab[forste];
		return fElm;
	}

	@Override
	public boolean erTom() {
		// TODO Auto-generated method stub
		boolean tom=false;
		if(antall==0) {
			tom=true;
		}
		return tom;
	}

	@Override
	public int antall() {
		// TODO Auto-generated method stub
		return antall;
	}


}
