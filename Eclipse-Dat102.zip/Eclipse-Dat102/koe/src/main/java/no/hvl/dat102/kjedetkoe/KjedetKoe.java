package no.hvl.dat102.kjedetkoe;

import no.hvl.dat102.adt.KoeADT;
import no.hvl.dat102.tabell.TabellKoe;

public class KjedetKoe<T> implements KoeADT<T> {
//denne m� kodes lages som lin�r node og implementere adt for koe
	private LinearNode<T> first= new LinearNode<>();
	private LinearNode<T> bakerste= new LinearNode<>();
	private int antall=0;
	
	
	@Override
	public void innKoe(T element) {
		// TODO Auto-generated method stub
		LinearNode<T> nynode=new LinearNode<>();
		if(first.getElement()==null) {
			first.setElement(element);
			bakerste=first;
			antall++;
		}else {
			nynode.setElement(element);
			bakerste.setNeste(nynode);
			bakerste=nynode;
			antall++;
		}
	}

	@Override
	public T utKoe() {
		// TODO Auto-generated method stub
		T element=null;
		if(first.getElement()!=null) {
			element=first.getElement();
			LinearNode<T> node= new LinearNode<>();
			node=first.getNeste();
			first.setNeste(null);
			first=node;
			antall--;
			return element;
		}
		return element;
	}

	@Override
	public T foerste() {
		// TODO Auto-generated method stub
		if(first==null) {
			return null;
		}
		return first.getElement();
	}

	@Override
	public boolean erTom() {
		// TODO Auto-generated method stub
		boolean tom=false;
		if(antall==0) {
			tom=true;
		}
		return tom;
	}

	@Override
	public int antall() {
		// TODO Auto-generated method stub
		return antall;
	}
}
