package no.hvl.dat102.kjedetstabel.kjedet;

import javax.lang.model.element.Element;

import no.hvl.dat102.kjedetstabel.adt.StabelADT;
import no.hvl.dat102.kjedetstabel.exception.EmptyCollectionException;

public class KjedetStabel<T> implements StabelADT<T> {
	private LinearNode<T> topp;
	private int antall;

	public KjedetStabel() {
		topp = null;
		antall = 0;
	}
	public LinearNode<T> hentSisteNode(){
		LinearNode<T> sisteNode=topp;
		if(topp!=null) {
			while(sisteNode.getNeste()!=null) {
				sisteNode=sisteNode.getNeste();
			}
		}
		return sisteNode;
		
	}

	@Override
	public void push(T el) {//FIFO struktur endre
		LinearNode<T> nynode = new LinearNode<T>(el);
		//TODO
		LinearNode<T> sistenode = null;
		if(topp==null) {
			topp=nynode;
			antall++;
		}else {
			nynode.setNeste(topp);
			topp=nynode;
			//sistenode=hentSisteNode();
			//sistenode.setNeste(nynode);
			antall++;
		}
		
	}

	@Override
	public T pop()  {
		//TODO
		T resultat=null;
		if(topp!=null) {
			resultat = topp.getElement();
			topp = topp.getNeste();
			antall--;
		}else {
			throw new EmptyCollectionException("stabel");
		}
		return resultat;
	}

	@Override
	public T peek() {
		if (erTom())
			throw new EmptyCollectionException("stabel");
		
		return topp.getElement();
	}

	@Override
	public boolean erTom() {
		return (antall == 0);
	}

	@Override
	public int antall() {
		return antall;
	}

}