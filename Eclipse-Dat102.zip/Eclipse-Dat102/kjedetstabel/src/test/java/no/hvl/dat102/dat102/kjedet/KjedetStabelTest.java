package no.hvl.dat102.dat102.kjedet;


import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

import no.hvl.dat102.dat102.adt.StabelADTTest;
import no.hvl.dat102.kjedetstabel.adt.StabelADT;
import no.hvl.dat102.kjedetstabel.exception.EmptyCollectionException;
import no.hvl.dat102.kjedetstabel.kjedet.KjedetStabel;

public class KjedetStabelTest extends StabelADTTest {
	   @Override
		protected StabelADT<Integer> reset() {
			return new KjedetStabel<Integer>();
	   }
}
