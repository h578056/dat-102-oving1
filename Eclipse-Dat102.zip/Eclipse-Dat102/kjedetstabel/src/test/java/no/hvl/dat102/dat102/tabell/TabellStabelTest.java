package no.hvl.dat102.dat102.tabell;


import no.hvl.dat102.dat102.adt.StabelADTTest;
import no.hvl.dat102.kjedetstabel.adt.StabelADT;
import no.hvl.dat102.kjedetstabel.tabell.TabellStabel;

public class TabellStabelTest extends StabelADTTest{	

		@Override
		protected StabelADT<Integer> reset() {
			return new TabellStabel<Integer>();
		}
		// Her kan en vel legge til test p� at stabelen
		// utvider seg
	}


