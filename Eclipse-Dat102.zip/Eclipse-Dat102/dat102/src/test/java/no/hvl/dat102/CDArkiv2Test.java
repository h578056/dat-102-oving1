package no.hvl.dat102;

import org.junit.Before;

public class CDArkiv2Test extends CDArkivTest {
	@Override 
	public void start() {
		arkiv=new CDArkiv2(); 
		CD nyCD=new CD(1, "meg", "sangtittel", 2012, "pop", "sony");
		arkiv.leggTilCD(nyCD);
		nyCD= new CD(2, "noen", "tittel2", 2013, "rock", "sony");
		arkiv.leggTilCD(nyCD);
	}
}
