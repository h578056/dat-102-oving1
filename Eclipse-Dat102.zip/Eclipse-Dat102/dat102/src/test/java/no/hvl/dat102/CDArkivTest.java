package no.hvl.dat102;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import no.hvl.data102.adt.CDArkivADT;

public class CDArkivTest {
	public CDArkivADT arkiv;
	
	@Before 
	public void start() {
		arkiv=new CDArkiv(10); 
		CD nyCD=new CD(1, "meg", "sangtittel", 2012, "pop", "sony");
		arkiv.leggTilCD(nyCD);
		nyCD= new CD(2, "noen", "tittel2", 2013, "rock", "sony");
		arkiv.leggTilCD(nyCD);
		
	}
	
	@Test
	public void testAntall() {
		assertEquals(2, arkiv.antall());
	}
	@Test
	public void testSlett() {
		arkiv.slettCd(1);
		assertEquals(1, arkiv.antall());
	}
	@Test
	public void testSlettAlle() {
		arkiv.slettCd(1);
		arkiv.slettCd(2);
		assertEquals(0, arkiv.antall());
	}
	@Test
	public void testsokTittel() {
		CD[] tab= arkiv.sokTittel("titt");
		assertEquals(2, tab.length);
	}
	@Test
	public void testsokArtist() {
		CD[] tab= arkiv.sokArtist("me");
		assertEquals(1, tab.length);
	}
	@Test
	public void testSjanger() {
		CD nyCD= new CD(3, "nNn", "tittel3", 2015, "rock", "sony");
		arkiv.leggTilCD(nyCD);
		int ant=arkiv.antallSjanger("rock");
		assertEquals(2, ant);
	}
}
