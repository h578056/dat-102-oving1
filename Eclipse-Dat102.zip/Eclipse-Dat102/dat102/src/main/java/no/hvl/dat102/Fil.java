package no.hvl.dat102;
import no.hvl.data102.adt.*;
import no.hvl.dat102.CD;
import no.hvl.data102.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.nio.file.*;
import java.util.Scanner;
public class Fil {
	final String SKILLE = "#"; // Eventuelt ha som parameter i metodene.
	private final static String cdFolder="CdArkivFiler/";
	 
	// Lese et CDarkiv fra tekstfil
	
	 public static CDArkivADT lesFraFil(String filnavn) {
		 File fil= new File(cdFolder+filnavn);
			try {
				Scanner leser= new Scanner(fil);
				int antCDer= Integer.parseInt(leser.nextLine());
				CDArkiv cdArkiv= new CDArkiv(antCDer+10);
				while(leser.hasNextLine()) {
					String linje=leser.nextLine();
					CD nycd=new CD();
					nycd.cdFraString(linje, "#");
					cdArkiv.leggTilCD(nycd);
				}
				leser.close();
				return cdArkiv;
			} catch (FileNotFoundException e) {
				System.out.println("filen ikke funnet");
				e.printStackTrace();
			}
			return null;
	} 
	// Lagre et CDarkiv til tekstfil
	 public static void skrivTilFil(CDArkivADT cdarkiv, String filnavn){
		 int antCD=cdarkiv.antall();
		 try {
			PrintWriter skriver= new PrintWriter(cdFolder+filnavn);
			skriver.println(antCD);
			CD[] alleCd=cdarkiv.hentCDTabell();
			for(int i=0; i<cdarkiv.antall(); i++) {
				//String cdTxt=cdarkiv.hentCDTabell()[i].cdStringForFil();
				if(alleCd[i]!=null) {
					String cdTxt=alleCd[i].cdStringForFil();
					skriver.println(cdTxt);
				}
			}
			skriver.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 } 
	 public static String[] filerIFolder() {
		 File filer= new File(cdFolder);
		 return filer.list();
	 }
	 public static void sletteFil(String filnavn) {
		 File fil= new File(cdFolder+filnavn);
		 if(fil!=null && fil.isFile()) {
			 fil.delete();
		 }
	 }
}
