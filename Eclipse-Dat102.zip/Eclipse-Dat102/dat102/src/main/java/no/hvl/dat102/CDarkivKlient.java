package no.hvl.dat102;

public class CDarkivKlient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//teste alle metodene, do while eller switch
		//CDArkiv cda= new CDArkiv(20);
		//Meny meny=new Meny(cda);
	}

}
