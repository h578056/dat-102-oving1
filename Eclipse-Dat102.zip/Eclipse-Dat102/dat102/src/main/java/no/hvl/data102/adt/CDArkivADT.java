package no.hvl.data102.adt;

import no.hvl.dat102.CD;

public interface CDArkivADT {
	/**
	 * hente en tabell med cd'er;
	 */
	public CD[] hentCDTabell();
	
	/**
	 *  Legger til en ny CD
	 */
	void leggTilCD(CD nycd);
	/**
	 *  Sletter en CD hvis den fins 
	 */
	boolean slettCd(int CdNr);
	/**
	 *  S�ker og henter CD-er med en gitt delstreng
	 */
	CD[] sokTittel(String delstreng);
	/**
	 * S�ker og henter artister med en gitt delstreng
	 */
	 CD[] sokArtist(String delstreng);
	 /**
	  * // Henter antall CD-er for en gitt sjanger
	  */
	 int antallSjanger(String sjanger);
	 /**
	  *  Returnerer antall CD-er
	  */
	 int antall();
	/**
	 * returnerer en cd hvid den finnes else null
	 * @param cdnummer
	 * @return
	 */
	CD hentCd(int cdnummer);

}
