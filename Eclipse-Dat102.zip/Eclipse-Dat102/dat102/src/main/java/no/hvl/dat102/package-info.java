/**
 * 
 */
/**
 * @author Stian
 *
 */
package no.hvl.dat102;