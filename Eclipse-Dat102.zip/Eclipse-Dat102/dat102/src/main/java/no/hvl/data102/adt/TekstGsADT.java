package no.hvl.data102.adt;

import no.hvl.dat102.CD;
import no.hvl.dat102.CDArkiv;
public interface TekstGsADT {
	// lese opplysningene om en CD fra tastatur
	 public CD lesCD();
	// vise en CD med alle opplysninger p� skjerm (husk tekst for sjanger)
	 public void visCD(CD cd);
	// Skrive ut alle CD-er med en spesiell delstreng i tittelen
	 public void skrivUtCdDelstrengITittel( String delstreng);
	// Skriver ut alle CD-er av en artist  en gruppe
	 public void skrivUtCdArtist(String delstreng);
	// Skrive ut en enkel statistikk som inneholder antall CD-er totalt
	// og hvor mange det er i hver sjanger
	 public void skrivUtStatistikk();
}
