package no.hvl.dat102;

import no.hvl.data102.adt.*;

public class CDArkiv2 implements CDArkivADT {
	private int antall;
	private LinearNode<CD> start;

	@Override
	public CD[] hentCDTabell() {
		CD[] cdTab = new CD[antall];
		if (start != null) {
			LinearNode<CD> node = start;
			for (int i = 0; i < antall; i++) {
				cdTab[i] = node.getElement();
				node.getNeste();
			}
		} else {
			cdTab = null;
		}
		return cdTab;
	}

	public LinearNode<CD> hentSisteNode() {
		LinearNode<CD> sisteNode = start;
		while (sisteNode.getNeste() != null) {
			sisteNode = sisteNode.getNeste();
		}
		return sisteNode;

	}

	@Override
	public void leggTilCD(CD nycd) {
		LinearNode<CD> nyNode = new LinearNode(nycd);
		if (start == null) {
			start = nyNode;
		} else {
			LinearNode<CD> sisteNode = hentSisteNode();
			sisteNode.setNeste(nyNode);
		}
		antall++;
	}

	public boolean slettForste() {
		boolean slettet = false;
		LinearNode<CD> node = start.getNeste();
		if (start.getNeste() != null) {
			start = node;
			start.setNeste(node.getNeste());
			;
			node.setNeste(null);
			slettet = true;
		} else {
			start = null;
			slettet = true;
		}
		return slettet;
	}

	@Override
	public boolean slettCd(int CdNr) {
		// TODO Auto-generated method stub
		boolean slettet = false;
		if (start != null) {
			LinearNode<CD> node = start.getNeste();
			LinearNode<CD> forgjeNode = start;
			if (start.getElement().getCdNr() == CdNr) {
				slettet = slettForste();
			} else {
				// LinearNode<CD> node=start.getNeste();
				// LinearNode<CD> forgjeNode=start;
				while (node.getNeste() != null && node.getElement().getCdNr() != CdNr) {
					if (node.getElement().getCdNr() == CdNr) {
						forgjeNode.setNeste(node.getNeste());
						node.setNeste(null);
						slettet = true;
					}
					node = node.getNeste();
					forgjeNode = forgjeNode.getNeste();
				}
			}
		}
		if (slettet = true) {
			antall--;
		}
		return slettet;
	}

	public CD[] fjerneTommePlasser(CD tabMTommePlasser[], int antINyTab) {
		CD CdDel[] = new CD[antINyTab];
		for (int i = 0; i < CdDel.length; i++) {
			CdDel[i] = tabMTommePlasser[i];
		}
		return CdDel;
	}

	@Override
	public CD[] sokTittel(String delstreng) {
		// TODO Auto-generated method stub
		CD[] tittelTab = new CD[antall];
		LinearNode<CD> node = start;
		int count = 0;
		do {		
			if (node.getElement() != null && node.getElement().getTittel().contains(delstreng)) {
				tittelTab[count] = node.getElement();
				node = node.getNeste();
				count++;
			}			
		}while(node!=null);
		tittelTab = fjerneTommePlasser(tittelTab, count);
		return tittelTab;
	}

	@Override
	public CD[] sokArtist(String delstreng) {
		// TODO Auto-generated method stub
		CD[] tittelTab = new CD[antall];
		LinearNode<CD> node = start;
		int count = 0;
		do {
			if (node.getElement() != null && node.getElement().getArtist().contains(delstreng)) {
				tittelTab[count] = node.getElement();
				count++;
			}
			node = node.getNeste();
		}while(node!=null);
		tittelTab = fjerneTommePlasser(tittelTab, count);
		return tittelTab;
	}

	@Override
	public int antallSjanger(String sjanger) {
		// TODO Auto-generated method stub
		int antSjanger = 0;
		LinearNode<CD> node = start;
		do {
			if (node.getElement() != null && node.getElement().getSjanger().contains(sjanger)) {
				antSjanger++;
			}
			node = node.getNeste();
		}while(node!=null);
		return antSjanger;
	}

	@Override
	public int antall() {
		// TODO Auto-generated method stub
		return antall;
	}

	@Override
	public CD hentCd(int cdnummer) {
		// TODO Auto-generated method stub
		CD hentetCd = null;
		LinearNode<CD> node = start;
		while(node.getNeste()!=null && node.getElement().getCdNr()!=cdnummer) {
			if(node.getElement().getCdNr()!=cdnummer) {
				hentetCd=node.getElement();
			}
			node=node.getNeste();
		}
		return hentetCd;
	}

}
