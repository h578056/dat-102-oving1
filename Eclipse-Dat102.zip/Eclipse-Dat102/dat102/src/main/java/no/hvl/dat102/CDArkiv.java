package no.hvl.dat102;

import no.hvl.data102.adt.CDArkivADT;

public class CDArkiv implements CDArkivADT{
	private CD CdSamling[];
	private int nesteLedig;
	public CDArkiv(int antPlasser) {
		CdSamling=new CD[antPlasser];
		nesteLedig=0;
	}
	
	@Override
	public CD[] hentCDTabell() {
		return CdSamling;
	}
	public boolean finnesFraFor(int CdNr) {
		boolean finnes=false;
		if(hentCd(CdNr)!=null) {
			finnes=true;
		}
		return finnes;
	}
	public CD hentCd(int CdNr) {
		for(int i=0; i<CdSamling.length; i++) {
			if(CdSamling[i]!=null && CdSamling[i].getCdNr()==CdNr) {
				return CdSamling[i];
			}
		}
		return null;
	}
	
	public void utvidTab() {
		int nyLengde=(int)(CdSamling.length*1.1);
		CD hjelpTab[]=new CD[nyLengde];
		for(int i=0;i<CdSamling.length; i++) {
			hjelpTab[i]=CdSamling[i];
		}
		CdSamling=hjelpTab;
	}
	
	@Override
	public void leggTilCD(CD nycd) {
		if(!finnesFraFor(nycd.getCdNr())) {
			if(nesteLedig==CdSamling.length) {
				utvidTab();
			}
			CdSamling[nesteLedig]=nycd;
			nesteLedig++;
		}
	}

	@Override
	public boolean slettCd(int CdNr) {
		boolean slettet=false;
		CD cdHold=null;
		if(finnesFraFor(CdNr)) {
			for(int i=0; i<CdSamling.length; i++) {
				if(CdSamling[i].getCdNr()==CdNr) {
					cdHold=CdSamling[nesteLedig-1];
					CdSamling[i]=cdHold;
					CdSamling[nesteLedig-1]=null;
					nesteLedig--;
					slettet=true;
					break;
				}
			}
		}
		return slettet;
	}
	public CD[] fjerneTommePlasser(CD tabMTommePlasser[], int antINyTab) {
		CD CdDel[]= new CD[antINyTab];
		for(int i=0; i<CdDel.length; i++) {
			CdDel[i]=tabMTommePlasser[i];
		}
		return CdDel;
	}

	@Override
	public CD[] sokTittel(String delstreng) {
		CD[] CDmid=new CD[CdSamling.length];
		int antINyTab=0;
		for(int i=0; i<CdSamling.length; i++) {
			if(CdSamling[i]!=null && CdSamling[i].getTittel().contains(delstreng)) {
				CDmid[antINyTab]=CdSamling[i];
				antINyTab++;
			}
		}
		CD CdDel[]= fjerneTommePlasser(CDmid, antINyTab);
		return CdDel;
		//kan gj�re samme i metoden under.
	}

	@Override
	public CD[] sokArtist(String delstreng) {
		CD CDArtistdelStreng[]= new CD[CdSamling.length];
		int antNyTab=0;
		for(int i=0; i<CdSamling.length; i++) {
			if(CdSamling[i]!=null && CdSamling[i].getArtist().contains(delstreng)) {
				CDArtistdelStreng[antNyTab]=CdSamling[i];
				antNyTab++;
			}
		}
		return CDArtistdelStreng;
	}

	@Override
	public int antallSjanger(String sjanger) {
		int antSjanger=0;
		for(int i=0; i<CdSamling.length; i++) {
			if(CdSamling[i]!=null && CdSamling[i].getSjanger().equals(sjanger)) {
				antSjanger++;
			}
		}
		return antSjanger;
	}

	@Override
	public int antall() {
		return nesteLedig;
	}

}
