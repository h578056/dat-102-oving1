/**
 * 
 */
/**
 * @author Stian
 *
 */
package no.hvl.data102.adt;