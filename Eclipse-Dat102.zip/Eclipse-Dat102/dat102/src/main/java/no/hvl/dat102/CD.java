package no.hvl.dat102;

public class CD {
	private int cdNr;
	private String artist;
	private String tittel;
	private int aarstall;
	private String sjanger;
	private String plateSelskap;
	
	public CD() {
	}
	public CD(int cdNr,String artist,String tittel, int aarstall,String sjanger, String plateSelskap) {
		this.cdNr=cdNr;
		this.artist=artist;
		this.tittel=tittel;
		this.aarstall=aarstall;
		this.sjanger=sjanger;
		this.plateSelskap=plateSelskap;
	}
	
	public void setAlle(int cdNr,String artist,String tittel, int aarstall,String sjanger, String plateSelskap) {
		this.cdNr=cdNr;
		this.artist=artist;
		this.tittel=tittel;
		this.aarstall=aarstall;
		this.sjanger=sjanger;
		this.plateSelskap=plateSelskap;
	}

	public int getCdNr() {
		return cdNr;
	}
	public void setCdNr(int cdNr) {
		this.cdNr = cdNr;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getTittel() {
		return tittel;
	}
	public void setTittel(String tittel) {
		this.tittel = tittel;
	}
	public int getAarstall() {
		return aarstall;
	}
	public void setAarstall(int aarstall) {
		this.aarstall = aarstall;
	}
	public String getSjanger() {
		return sjanger;
	}
	public void setSjanger(String sjanger) {
		this.sjanger = sjanger;
	}
	public String getPlateSelskap() {
		return plateSelskap;
	}
	public void setPlateSelskap(String plateSelskap) {
		this.plateSelskap = plateSelskap;
	}
	
	@Override
	public String toString() {
		return "CD [cdNr=" + cdNr + ", artist=" + artist + ", tittel=" + tittel + ", aarstall=" + aarstall
				+ ", sjanger=" + sjanger + ", plateSelskap=" + plateSelskap + "]";
	}
	public void cdFraString(String cdString, String skilletegn) {
		String[] cdsplitt=cdString.split(skilletegn);
		int cdNr=Integer.parseInt(cdsplitt[0]);
		String artist=cdsplitt[1];
		String tittel=cdsplitt[2];
		int aarstall=Integer.parseInt(cdsplitt[3]);
		String sjanger=cdsplitt[4];
		String plateSelskap=cdsplitt[5];
		setAlle(cdNr, artist, tittel, aarstall, sjanger, plateSelskap);
	}
	public String cdStringForFil() {
		String cdforFil=cdNr+"#"+artist+"#"+tittel+"#"+aarstall+"#"+sjanger+"#"+plateSelskap;
		return cdforFil; 
	}

}
