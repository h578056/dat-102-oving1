package no.hvl.dat102;
import javax.swing.JOptionPane;

import no.hvl.data102.adt.CDArkivADT;
import no.hvl.data102.adt.TekstGsADT;

public class TekstGrensesnitt implements TekstGsADT{
	private CDArkivADT arkiv;
	
	public TekstGrensesnitt(CDArkivADT arkiv){
		this.arkiv=arkiv;
	}
	//skrive ut cden sine opplysninger, bbestemme hvordan

	
	public void skrivUtCdDelstrengITittel(String delstreng) {
		CD CDTab[]= arkiv.sokTittel(delstreng);
		StringBuffer samle= new StringBuffer();
		for(int i=0; i<CDTab.length; i++) {
			samle.append(CDTab[i].toString());
			samle.append("\n");
		}
		visStreng(samle.toString());
	}
	@Override
	public CD lesCD() {
		// TODO Auto-generated method stub
		String cdNrTxt=JOptionPane.showInputDialog("CD nr");
		int cdNr=Integer.parseInt(cdNrTxt);
		String artist=JOptionPane.showInputDialog("artist");
		String tittel=JOptionPane.showInputDialog("tittel");
		String aarstallTxt=JOptionPane.showInputDialog("�rstall");
		int aarstall=Integer.parseInt(aarstallTxt);
		String sjanger=JOptionPane.showInputDialog("sjanger");
		String plateSelskap=JOptionPane.showInputDialog("plateselskap");
		CD cdLes= new CD(cdNr, artist, tittel, aarstall, sjanger, plateSelskap);
		return cdLes;
	

	}
	public void visStreng(String noe) {
		JOptionPane.showMessageDialog(null,noe, "Info", 0);
	}
	@Override
	public void visCD(CD cd) {
		if(cd!=null) {
			visStreng(cd.toString());
		}else {
			visStreng("fant ikke cd");
		}
	}
	@Override
	public void skrivUtCdArtist(String delstreng) {
		// TODO Auto-generated method stub
		CD cdTab[]= arkiv.sokArtist(delstreng);
		StringBuffer samle= new StringBuffer();
		for(int i=0; i<cdTab.length; i++) {
			if(cdTab[i]!=null) {
				samle.append(cdTab[i].toString());
				samle.append("\n");
			}
		}
		visStreng(samle.toString());
	}
	@Override
	public void skrivUtStatistikk() {
		// TODO Auto-generated method stub'
		CD[] cdTab= arkiv.hentCDTabell();
		int pop=0;
		int rock=0;
		int rap=0;
		int opera=0;
		int annet=0;
	for(int i=0; i<arkiv.antall(); i++) {
		if(cdTab[i]!=null) {
			if(cdTab[i].getSjanger().equals("pop")) {
				pop++;
			}else if(cdTab[i].getSjanger().equals("rock")) {
				rock++;
			}else if(cdTab[i].getSjanger().equals("rap")) {
				rap++;
			}else if(cdTab[i].getSjanger().equals("opera")) {
				opera++;
			}else {
				annet++;
			}
		}	
	}
	visStreng(("pop: " + pop+ "\n" + "rock: " + rock +"\n" + "rap: " + rap + "\n"+ "opera: " + opera+ "\n"+ "annet: "+annet+ "\n"));
		
	}
	public static void main(String[]args) {
		CD cdtest= new CD(1, "srtist", "tittel", 1900, "pop", "sony");
		CDArkiv testArk= new CDArkiv(3);
		testArk.leggTilCD(cdtest);
		TekstGrensesnitt test= new TekstGrensesnitt(testArk);
		test.skrivUtCdDelstrengITittel("tt");
		System.out.println("skriv ut");
		
	}

	
}
