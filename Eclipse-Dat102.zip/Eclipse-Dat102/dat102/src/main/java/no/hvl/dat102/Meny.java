package no.hvl.dat102;

import javax.swing.JOptionPane;

import org.w3c.dom.css.ViewCSS;

import no.hvl.data102.adt.CDArkivADT;

public class Meny {
	private TekstGrensesnitt tekstGS;
	private CDArkivADT cdArkiv;
	
	public Meny() {
		tekstGS= null;
		cdArkiv=null;
	}
	public void start() {
		//hva skal her?
	}
	public void hovedMeny() {
		StringBuffer menyValg= new StringBuffer();
		menyValg.append( "Skriv tall for operasjon \n");
		menyValg.append( "1: nytt arkiv \n ");
		menyValg.append( "2: gammelt arkiv \n");
		menyValg.append( "3: slette arkiv  \n");
		menyValg.append( "4: lagre \n");
		menyValg.append( "5: avslutt \n");
		boolean ikkeFerdig=true;
		do {
			String tallTxt= JOptionPane.showInputDialog(menyValg.toString());
			if(tallTxt!=null) {
				switch(tallTxt){
				case "1": nyttArkiv(); break;
				case "2": gammeltSlettArkiv(true); break;
				case "3": gammeltSlettArkiv(false); break;
				case "4" : lagre(); break;
				default : ikkeFerdig=false;
				}
			}else{
				ikkeFerdig=false;
			}
		}while(ikkeFerdig);
	}
	private void lagre() {
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("Skriv inn filnavn");
		String filnavn= JOptionPane.showInputDialog(menyValg.toString());
		if(filnavn!=null) {
			//husk � kalle fil lagre metode;
			Fil.skrivTilFil(cdArkiv, filnavn);
		}
	}
	private void gammeltSlettArkiv(boolean gammeltArkiv) {
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("oppgi nr for fil som skal");
		if(gammeltArkiv) {
			menyValg.append(" �pnes \n");
		}else {
			menyValg.append(" slettes \n");
		}
		String liste[]=Fil.filerIFolder();
		for(int i=0; i<liste.length; i++) {
			menyValg.append(i + ") "+liste[i]+"\n"); 
		}
		String filnavn= JOptionPane.showInputDialog(menyValg.toString());
		if(filnavn!=null) {
			int filNr=Integer.parseInt(filnavn);
			if(gammeltArkiv) {
				//kalle fil metode for � �pne fil i liste[filnavn];
				cdArkiv=Fil.lesFraFil(liste[filNr]);
				tekstGS= new TekstGrensesnitt(cdArkiv);
				metoderForArkiv();
			}else {
				Fil.sletteFil(liste[filNr]);
			}
		}
		
	}
	private void nyttArkiv() {
		// TODO Auto-generated method stub
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("Antall plasser i arkiv");
		String plasser= JOptionPane.showInputDialog(menyValg.toString());
		if(plasser!=null) {
			int antPlasser=Integer.parseInt(plasser);
			cdArkiv= new CDArkiv(antPlasser);
			tekstGS= new TekstGrensesnitt(cdArkiv);
			metoderForArkiv();
		}
		
		
	}
	private void metoderForArkiv() {
		// TODO Auto-generated method stub
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("oppgi nr for metode som skal kj�res \n");
		menyValg.append( "1: sjekk om cd finnes fra f�r \n ");
		menyValg.append( "2: slette cd \n ");
		menyValg.append( "3: legg til cd \n ");
		menyValg.append( "4: s�k Tittel\n ");
		menyValg.append( "5: s�k artist \n ");
		menyValg.append( "6: antall sjanger \n ");
		menyValg.append( "7: skriv ut statistikk \n ");
		menyValg.append( "antall cd'er: "+cdArkiv.antall()+"\n");
		menyValg.append( "8: til hovedmeny\n ");
		boolean ikkeFerdig=true;
		do {
			String tallTxt= JOptionPane.showInputDialog(menyValg.toString());
			if(tallTxt!=null) {
				switch(tallTxt){
				case "1": sjekkCD(); break;
				case "2": slettCD(); break;
				case "3": leggtilCD(); break;
				case "4" : s�kTittel(); break;
				case "5" : s�kArtist(); break;
				case "6" : antallSjanger(); break;
				case "7" : skrivUtStatistikk(); break;
				default : ikkeFerdig=false;
				}
			}else{
				ikkeFerdig=false;
			}
		}while(ikkeFerdig);
		
	}
	private void skrivUtStatistikk() {
		// TODO Auto-generated method stub
		tekstGS.skrivUtStatistikk();
	}
	private void antallSjanger() {
		// TODO Auto-generated method stub
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("oppgi sjanger som det skal s�kes p� \n");
		String sjanger= JOptionPane.showInputDialog(menyValg.toString());
		int antSjanger= cdArkiv.antallSjanger(sjanger);
		tekstGS.visStreng("Antall av sjanger: "+antSjanger);
	}

	private void s�kArtist() {
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("oppgi artist som det skal s�kes p� \n");
		String artist= JOptionPane.showInputDialog(menyValg.toString());
		tekstGS.skrivUtCdArtist(artist);
	}
	private void s�kTittel() {
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("oppgi tittel som det skal s�kes p� \n");
		String title= JOptionPane.showInputDialog(menyValg.toString());
		tekstGS.skrivUtCdDelstrengITittel(title);
	}
	private void leggtilCD() {
		// TODO Auto-generated method stub
		CD cd=tekstGS.lesCD();
		cdArkiv.leggTilCD(cd);
	}
	private void slettCD() {
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("oppgi cd nr som skal slettes \n");
		for(int i=0; i<cdArkiv.antall(); i++) {
			if( cdArkiv.hentCDTabell()[i]!=null) {
				menyValg.append(i + ") "+ cdArkiv.hentCDTabell()[i].getTittel());
			}
		}
		String tallTxt= JOptionPane.showInputDialog(menyValg.toString());
		if(tallTxt!=null) {
			int tall= Integer.parseInt(tallTxt);
			cdArkiv.slettCd(cdArkiv.hentCDTabell()[tall].getCdNr());
		}
		
	}
	private void sjekkCD() {
		StringBuffer menyValg= new StringBuffer();
		menyValg.append("oppgi cd nr som det skal s�kes p� \n");
		String plasser= JOptionPane.showInputDialog(menyValg.toString());
		int cdnummer= Integer.parseInt(plasser);
		tekstGS.visCD(cdArkiv.hentCd(cdnummer));
		
	
		
	}
	public static void main(String[] args) {
		Meny myhovdmeny= new Meny();
		myhovdmeny.hovedMeny();
	}
}
